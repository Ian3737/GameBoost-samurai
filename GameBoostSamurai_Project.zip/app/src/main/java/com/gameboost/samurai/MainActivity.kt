
package com.gameboost.samurai;

import android.os.Bundle;
import androidx.activity.ComponentActivity;
import androidx.activity.compose.setContent;
import androidx.compose.foundation.layout.*;
import androidx.compose.foundation.lazy.LazyColumn;
import androidx.compose.foundation.lazy.items;
import androidx.compose.material.*;
import androidx.compose.runtime.*;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.unit.dp;

public class MainActivity extends ComponentActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContent(() -> {
            GameBoostTheme(() -> {
                Surface(modifier = Modifier.fillMaxSize(), () -> {
                    GameBoostApp();
                });
            });
        });
    }

    @Composable
    public void GameBoostApp() {
        var games = remember(() -> java.util.List.of("Game 1", "Game 2", "Game 3"));
        var boosting = remember(() -> false);

        Row(modifier = Modifier.fillMaxSize(), () -> {
            LazyColumn(modifier = Modifier.weight(1f), () -> {
                items(games, game -> {
                    Text(game, modifier = Modifier.padding(8.dp));
                });
            });
            Column(modifier = Modifier.weight(2f).fillMaxHeight(),
                   verticalArrangement = Arrangement.Center,
                   horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally, () -> {
                Button(() -> boosting = !boosting, modifier = Modifier.size(200.dp), () -> {
                    Text(boosting ? "ブースト / BOOSTING" : "ブースト / BOOST");
                });
            });
        });
    }
}
